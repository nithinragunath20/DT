"""
QLoRA fine-tuning for Qwen/Qwen3-4B.
Configuration mirrors the original Colab notebook.
"""
import argparse
import json
import os
import time

import torch
from datasets import load_from_disk
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    BitsAndBytesConfig,
    DataCollatorForLanguageModeling,
    TrainingArguments,
    Trainer,
)
from peft import (
    LoraConfig,
    prepare_model_for_kbit_training,
    get_peft_model,
)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data/processed")
    parser.add_argument("--output-dir", default="outputs/SLM_Final_Output")
    parser.add_argument("--model-name", default="Qwen/Qwen3-4B")
    parser.add_argument("--max-steps", type=int, default=10)
    args = parser.parse_args()

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU is required for this 4-bit QLoRA configuration.")

    train_text = load_from_disk(os.path.join(args.data_dir, "train"))
    validation_text = load_from_disk(os.path.join(args.data_dir, "validation"))
    test_text = load_from_disk(os.path.join(args.data_dir, "test"))

    tokenizer = AutoTokenizer.from_pretrained(args.model_name)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    quant_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_use_double_quant=True,
    )

    model = AutoModelForCausalLM.from_pretrained(
        args.model_name,
        quantization_config=quant_config,
        device_map="auto",
        torch_dtype=torch.float16,
    )

    model.config.use_cache = False
    model = prepare_model_for_kbit_training(
        model,
        use_gradient_checkpointing=True,
    )

    lora_config = LoraConfig(
        r=8,
        lora_alpha=16,
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    max_length = 256

    def tokenize_function(examples):
        return tokenizer(
            examples["text"],
            truncation=True,
            max_length=max_length,
            padding=False,
        )

    train_tokens = train_text.map(
        tokenize_function, batched=True, remove_columns=train_text.column_names
    )
    val_tokens = validation_text.map(
        tokenize_function, batched=True, remove_columns=validation_text.column_names
    )
    test_tokens = test_text.map(
        tokenize_function, batched=True, remove_columns=test_text.column_names
    )

    data_collator = DataCollatorForLanguageModeling(
        tokenizer=tokenizer,
        mlm=False,
    )

    training_args = TrainingArguments(
        output_dir=os.path.join(args.output_dir, "training_runs"),
        per_device_train_batch_size=1,
        per_device_eval_batch_size=1,
        gradient_accumulation_steps=2,
        learning_rate=1e-4,
        max_steps=args.max_steps,
        logging_steps=1,
        eval_strategy="steps",
        eval_steps=5,
        save_strategy="no",
        fp16=True,
        optim="paged_adamw_8bit",
        gradient_checkpointing=True,
        report_to="none",
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_tokens,
        eval_dataset=val_tokens,
        data_collator=data_collator,
        processing_class=tokenizer,
    )

    start_time = time.time()
    train_result = trainer.train()
    training_time = time.time() - start_time

    test_results = trainer.evaluate(eval_dataset=test_tokens)

    adapter_dir = os.path.join(args.output_dir, "Qwen3_Finetuned_Adapter")
    os.makedirs(args.output_dir, exist_ok=True)
    model.save_pretrained(adapter_dir)
    tokenizer.save_pretrained(adapter_dir)

    results = {
        "model": args.model_name,
        "gpu": torch.cuda.get_device_name(0),
        "dataset_records": len(train_text) + len(validation_text) + len(test_text),
        "training_records": len(train_text),
        "validation_records": len(validation_text),
        "testing_records": len(test_text),
        "training_time_minutes": round(training_time / 60, 2),
        "training_metrics": train_result.metrics,
        "test_metrics": test_results,
        "quantization": "4-bit NF4",
        "lora": {"r": 8, "lora_alpha": 16, "lora_dropout": 0.05},
    }

    with open(os.path.join(args.output_dir, "evaluation_results.json"), "w") as f:
        json.dump(results, f, indent=4, default=str)

    print("Training completed.")
    print("Adapter saved to:", adapter_dir)
    print("Training time (minutes):", round(training_time / 60, 2))
    print("Test results:", test_results)


if __name__ == "__main__":
    main()
