"""
Preprocess an Arrow IPC dataset into small train/validation/test splits.

This follows the original notebook:
- Read Arrow IPC file (with stream/Feather fallbacks).
- Shuffle with seed 42 and select 10 records.
- Split 80% train, 10% validation, 10% test (8/1/1 records).
- Convert each telemetry row into the prompt format used for fine-tuning.
"""
import argparse
import json
import os

import pyarrow as pa
import pyarrow.ipc as ipc
import pyarrow.feather as feather
from datasets import Dataset


def read_arrow(path):
    try:
        with pa.memory_map(path, "r") as source:
            return ipc.open_file(source).read_all()
    except Exception:
        try:
            with pa.memory_map(path, "r") as source:
                return ipc.open_stream(source).read_all()
        except Exception:
            return feather.read_table(path)


def convert_record(record):
    clean_record = {key: value for key, value in record.items() if value is not None}
    telemetry = json.dumps(clean_record, default=str, separators=(",", ":"))
    return {
        "text": (
            "### Task:\n"
            "Analyze the following Linux system-call telemetry record.\n\n"
            "### Telemetry:\n"
            f"{telemetry}\n\n"
            "### Response:\n"
            "Describe the observable system activity using only "
            "the information present in the telemetry."
        )
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path to .arrow file")
    parser.add_argument("--output", default="data/processed")
    parser.add_argument("--records", type=int, default=10)
    args = parser.parse_args()

    table = read_arrow(args.input)
    dataset = Dataset(table)
    count = min(args.records, len(dataset))
    small_dataset = dataset.shuffle(seed=42).select(range(count))

    if count < 3:
        raise ValueError("At least 3 records are needed for train/validation/test splits.")

    split1 = small_dataset.train_test_split(test_size=0.2, seed=42)
    train_data = split1["train"]
    split2 = split1["test"].train_test_split(test_size=0.5, seed=42)
    validation_data = split2["train"]
    test_data = split2["test"]

    train_text = train_data.map(convert_record)
    validation_text = validation_data.map(convert_record)
    test_text = test_data.map(convert_record)

    os.makedirs(args.output, exist_ok=True)
    train_text.save_to_disk(os.path.join(args.output, "train"))
    validation_text.save_to_disk(os.path.join(args.output, "validation"))
    test_text.save_to_disk(os.path.join(args.output, "test"))
    small_dataset.save_to_disk(os.path.join(args.output, "reduced_dataset"))

    print(f"Original records: {len(dataset)}")
    print(f"Selected records: {count}")
    print(f"Training: {len(train_text)}")
    print(f"Validation: {len(validation_text)}")
    print(f"Testing: {len(test_text)}")
    print(f"Saved processed splits to: {args.output}")


if __name__ == "__main__":
    main()
