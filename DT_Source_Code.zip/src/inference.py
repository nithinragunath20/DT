"""Run a simple generation with the fine-tuned Qwen3 LoRA adapter."""
import argparse
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from peft import PeftModel


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--adapter-dir", default="outputs/SLM_Final_Output/Qwen3_Finetuned_Adapter")
    parser.add_argument("--model-name", default="Qwen/Qwen3-4B")
    parser.add_argument(
        "--prompt",
        default=(
            "### Task:\nAnalyze the following Linux system-call telemetry record.\n\n"
            "### Telemetry:\n{}\n\n### Response:\n"
            "Describe the observable system activity using only the information present in the telemetry."
        ),
    )
    args = parser.parse_args()

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU is required for this 4-bit setup.")

    tokenizer = AutoTokenizer.from_pretrained(args.adapter_dir)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    quant_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_use_double_quant=True,
    )
    base = AutoModelForCausalLM.from_pretrained(
        args.model_name,
        quantization_config=quant_config,
        device_map="auto",
        torch_dtype=torch.float16,
    )
    model = PeftModel.from_pretrained(base, args.adapter_dir)
    model.eval()

    inputs = tokenizer(args.prompt, return_tensors="pt").to(model.device)
    with torch.no_grad():
        output = model.generate(
            **inputs,
            max_new_tokens=160,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
        )
    print(tokenizer.decode(output[0], skip_special_tokens=True))


if __name__ == "__main__":
    main()
