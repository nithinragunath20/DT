"""Evaluate the saved Qwen3 LoRA adapter on the held-out test split."""
import argparse
import json
import os

import torch
from datasets import load_from_disk
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    BitsAndBytesConfig,
    DataCollatorForLanguageModeling,
    Trainer,
    TrainingArguments,
)
from peft import PeftModel


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default="data/processed")
    parser.add_argument("--adapter-dir", default="outputs/SLM_Final_Output/Qwen3_Finetuned_Adapter")
    parser.add_argument("--model-name", default="Qwen/Qwen3-4B")
    parser.add_argument("--output", default="outputs/test_evaluation.json")
    args = parser.parse_args()

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU is required.")

    test_text = load_from_disk(os.path.join(args.data_dir, "test"))
    tokenizer = AutoTokenizer.from_pretrained(args.adapter_dir)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    quant_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_use_double_quant=True,
    )
    base_model = AutoModelForCausalLM.from_pretrained(
        args.model_name,
        quantization_config=quant_config,
        device_map="auto",
        torch_dtype=torch.float16,
    )
    model = PeftModel.from_pretrained(base_model, args.adapter_dir)

    test_tokens = test_text.map(
        lambda x: tokenizer(x["text"], truncation=True, max_length=256, padding=False),
        batched=True,
        remove_columns=test_text.column_names,
    )
    collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)
    eval_args = TrainingArguments(
        output_dir="outputs/evaluation_run",
        per_device_eval_batch_size=1,
        report_to="none",
    )
    trainer = Trainer(
        model=model,
        args=eval_args,
        eval_dataset=test_tokens,
        data_collator=collator,
        processing_class=tokenizer,
    )
    results = trainer.evaluate()
    os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
    with open(args.output, "w") as f:
        json.dump(results, f, indent=4, default=str)
    print(results)


if __name__ == "__main__":
    main()
