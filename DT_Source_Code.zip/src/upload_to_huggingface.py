"""Optional: upload processed splits to a Hugging Face dataset repo.

Set HF_TOKEN in the environment before running. Never hard-code your token.
"""
import argparse
import os
from huggingface_hub import HfApi


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-id", default="nithinragunath/DT")
    parser.add_argument("--data-dir", default="data/processed")
    args = parser.parse_args()

    token = os.environ.get("HF_TOKEN")
    if not token:
        raise RuntimeError("Set the HF_TOKEN environment variable first.")

    api = HfApi(token=token)
    api.create_repo(repo_id=args.repo_id, repo_type="dataset", exist_ok=True)

    split_map = {
        "train": "train_dataset",
        "test": "test_dataset",
        "validation": "validation_dataset",
    }
    for local_name, repo_name in split_map.items():
        local_path = os.path.join(args.data_dir, local_name)
        if os.path.isdir(local_path):
            api.upload_folder(
                folder_path=local_path,
                path_in_repo=repo_name,
                repo_id=args.repo_id,
                repo_type="dataset",
            )
            print("Uploaded:", repo_name)
        else:
            print("Not found, skipping:", local_path)


if __name__ == "__main__":
    main()
