# Qwen3-4B SLM Fine-Tuning — Linux Cybersecurity Telemetry

This repository contains the source code used in the uploaded Google Colab notebook `notebooks/Qwen3_Training_Original.ipynb`, organized into reusable Python scripts.

## Project workflow

1. Read a Linux telemetry `.arrow` file.
2. Shuffle with seed `42` and select 10 records.
3. Split the selected records into train, validation, and test sets.
4. Convert each record into the notebook's instruction-style text format.
5. Fine-tune `Qwen/Qwen3-4B` using 4-bit NF4 quantization and LoRA.
6. Evaluate on the held-out test split and save the LoRA adapter and evaluation JSON.

## Dataset size used in the notebook

The notebook selects **10 records from one uploaded Arrow file**, then creates:
- Train: 8 records
- Validation: 1 record
- Test: 1 record

These are small demonstration splits, not a full-scale training dataset.

## Model and training configuration

- Base model: `Qwen/Qwen3-4B`
- Quantization: 4-bit NF4, double quantization enabled
- Compute dtype: `float16`
- LoRA rank (`r`): `8`
- LoRA alpha: `16`
- LoRA dropout: `0.05`
- Target modules: `q_proj`, `k_proj`, `v_proj`, `o_proj`
- Maximum sequence length: `256`
- Per-device batch size: `1`
- Gradient accumulation steps: `2`
- Learning rate: `1e-4`
- Training steps: `10` in the original notebook
- Optimizer: `paged_adamw_8bit`
- GPU used in the recorded run: Google Colab Tesla T4

## Project structure

```text
DT/
├── notebooks/
│   └── Qwen3_Training_Original.ipynb
├── src/
│   ├── preprocessing.py
│   ├── train.py
│   ├── evaluate.py
│   ├── inference.py
│   └── upload_to_huggingface.py
├── requirements.txt
├── .gitignore
└── README.md
```

## Setup

Use a CUDA-enabled environment (the original run used Google Colab with a Tesla T4).

```bash
pip install -r requirements.txt
```

## Run the pipeline

### 1. Prepare the datasets

Provide the Arrow file you want to use:

```bash
python src/preprocessing.py --input /path/to/telemetry.arrow --output data/processed
```

The script saves the Hugging Face `Dataset` splits under `data/processed/`.

### 2. Fine-tune Qwen3

```bash
python src/train.py --data-dir data/processed --output-dir outputs/SLM_Final_Output
```

To reproduce the notebook's short run, the default is 10 training steps. The adapter is saved to:

```text
outputs/SLM_Final_Output/Qwen3_Finetuned_Adapter/
```

The evaluation report is saved to:

```text
outputs/SLM_Final_Output/evaluation_results.json
```

### 3. Evaluate separately (optional)

```bash
python src/evaluate.py \
  --data-dir data/processed \
  --adapter-dir outputs/SLM_Final_Output/Qwen3_Finetuned_Adapter
```

### 4. Run inference (optional)

```bash
python src/inference.py \
  --adapter-dir outputs/SLM_Final_Output/Qwen3_Finetuned_Adapter
```

Edit the prompt in `src/inference.py` or pass your own telemetry prompt by adapting the script.

## Hugging Face upload (optional)

Set your token as an environment variable; do not paste tokens into source files.

PowerShell:

```powershell
$env:HF_TOKEN = "YOUR_HUGGING_FACE_WRITE_TOKEN"
python src/upload_to_huggingface.py --repo-id nithinragunath/DT
```

The upload script maps the local `train`, `test`, and `validation` split folders to `train_dataset`, `test_dataset`, and `validation_dataset` in the Hugging Face repository.

## Important notes

- The original notebook was retained in `notebooks/` for traceability.
- The scripts are a cleaned, modular organization of the notebook's workflow. They are not a byte-for-byte export of individual notebook cells.
- The 10-record split is intentionally tiny because that is what the notebook selected.
- The LoRA adapter is not a standalone full model. Load it together with the matching base model `Qwen/Qwen3-4B`.
- Large datasets, model weights, and adapter files should generally be stored in a dataset/model repository or Git LFS rather than committed as ordinary Git files.
- Never commit API tokens, passwords, or private credentials.
